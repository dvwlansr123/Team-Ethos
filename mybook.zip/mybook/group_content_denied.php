<div style="padding: 1em;text-align: center;background-color: white;margin-top: 2px;">
Join the group to see what the members are up to!
</div>